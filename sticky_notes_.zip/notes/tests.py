from django.test import TestCase
from .models import Note
from django.urls import reverse

class NoteModelTest(TestCase):
    def setUp(self):
        self.note = Note.objects.create(title="Test", content="Content")

    def test_note_creation(self):
        self.assertEqual(self.note.title, "Test")
        self.assertEqual(self.note.content, "Content")

class NoteViewTest(TestCase):
    def setUp(self):
        self.note = Note.objects.create(title="Test", content="Content")

    def test_note_list_view(self):
        response = self.client.get(reverse('note_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Test")

    def test_note_detail_view(self):
        response = self.client.get(reverse('note_detail', args=[self.note.id]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Content")
