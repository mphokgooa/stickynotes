from django.shortcuts import render
from .models import Note
from django.contrib.auth.decorators import login_required
@login_required
def index(request):
    notes = Note.objects.filter(owner=request.user).order_by('-modified')
    return render(request, 'notes/index.html', {'notes': notes})
